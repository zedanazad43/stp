# 🏛️ نظام توثيق وتداول الطوابع
## Stamp Authentication & Trading System

<div dir="rtl">

---

## 📋 جدول المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [الميزات الرئيسية](#الميزات-الرئيسية)
3. [البنية التقنية](#البنية-التقنية)
4. [دليل الاستخدام](#دليل-الاستخدام)
5. [API Documentation](#api-documentation)
6. [قاعدة البيانات](#قاعدة-البيانات)
7. [الأمان والضمان](#الأمان-والضمان)
8. [الأسعار والرسوم](#الأسعار-والرسوم)

---

## 🎯 نظرة عامة

### ما هو هذا النظام؟

نظام متكامل يتيح لأصحاب الطوابع:

1. ✅ **رفع صور طوابعهم** إلى المنصة
2. ✅ **توثيقها كـ NFTs** على البلوكشين
3. ✅ **تداول صور NFT** (الصورة الرقمية)
4. ✅ **تداول الطوابع الحقيقية** مع نظام ضمان
5. ✅ **التتبع الكامل للشحن** والفواتير
6. ✅ **الحماية من الاحتيال** عبر نظام الرصيد الاحتياطي

---

## 🚀 الميزات الرئيسية

### 1. رفع وتوثيق الطوابع

```
المستخدم يرفع صورة الطابع + معلومات
         ↓
المنصة تراجع وتوثق الطابع
         ↓
حساب تكلفة السك (بناءً على القيمة والندرة)
         ↓
المستخدم يدفع بـ StampCoins
         ↓
سك NFT على Polygon + تخزين IPFS
         ↓
إصدار شهادة توثيق رقمية
```

**الحقول المطلوبة:**
- عنوان الطابع
- الوصف
- الدولة
- السنة (1840-2030)
- الفئة (denomination)
- الحالة (mint, very_fine, fine, used, poor)
- الندرة (common, uncommon, rare, very_rare, legendary)
- القيمة المقدرة (USD)
- صور (حتى 10 صور)

**الحالات (Status):**
- `pending_verification`: في انتظار التحقق من الخبراء
- `verified`: تم التحقق - جاهز للدفع
- `rejected`: مرفوض
- `payment_received`: تم الدفع - جاري السك
- `minting`: جاري السك على البلوكشين
- `minted`: تم السك بنجاح ✅
- `failed`: فشل

---

### 2. حساب تكلفة السك

**المعادلة:**

```javascript
baseCost = stampValue × 0.01 (1%)

rarityMultipliers = {
  common: 1.0x
  uncommon: 1.2x
  rare: 1.5x
  very_rare: 2.0x
  legendary: 3.0x
}

platformFee = $5 USD
gasFee = $0.50 USD

totalUSD = (baseCost × rarityMultiplier) + platformFee + gasFee
totalStampCoins = Math.ceil(totalUSD × 10)
```

**أمثلة:**

| قيمة الطابع | الندرة | التكلفة النهائية |
|------------|--------|------------------|
| $100 | Common | 66 StampCoins ($6.60) |
| $500 | Rare | 133 StampCoins ($13.30) |
| $1,000 | Very Rare | 256 StampCoins ($25.60) |
| $5,000 | Legendary | 756 StampCoins ($75.60) |

---

### 3. تداول الطوابع الحقيقية

#### آلية الضمان (Escrow)

```
البائع والمشتري يتفقان على السعر
         ↓
حساب الرصيد الاحتياطي المطلوب:
  • المشتري: السعر + الشحن + 10% ضمان
  • البائع: 20% من قيمة الطابع
         ↓
قفل الأموال في حساب ضمان
         ↓
البائع يشحن الطابع
         ↓
رفع معلومات الشحن (رقم التتبع، فواتير، صور)
         ↓
المشتري يستلم الطابع
         ↓
المشتري يؤكد الاستلام والحالة
         ↓
إطلاق الأموال من الضمان:
  • البائع: يستلم السعر المتفق عليه
  • المشتري: استرداد الضمان (10%)
  • المنصة: أتعاب 5%
```

#### حساب الضمان

```javascript
// مثال: طابع بقيمة $1,000
agreedPrice = $1,000
shippingCost = $50

buyerDeposit = $1,000 + $50 + ($1,000 × 0.10) = $1,150
sellerDeposit = $1,000 × 0.20 = $200
platformFee = $1,000 × 0.05 = $50

totalEscrow = $1,350 (مقفول مؤقتاً)
```

#### شركات الشحن المدعومة

- ✅ DHL Express
- ✅ FedEx International
- ✅ UPS Worldwide
- ✅ USPS
- ✅ Aramex

#### التوثيق المطلوب

1. **من البائع:**
   - صور تغليف الطابع (قبل الشحن)
   - فاتورة الشحن (Shipping Receipt)
   - رقم التتبع (Tracking Number)
   - شهادة التأمين

2. **من المشتري:**
   - صور استلام الطابع
   - تقييم الحالة (1-5 نجوم)
   - ملاحظات (اختياري)

---

### 4. حل النزاعات

إذا لم تطابق حالة الطابع الوصف:

```
المشتري يختار "لا تطابق الحالة"
         ↓
فتح نزاع تلقائياً
         ↓
تجميد الأموال في الضمان
         ↓
فريق الدعم يراجع:
  • صور البائع (قبل الشحن)
  • صور المشتري (عند الاستلام)
  • فواتير الشحن
  • التتبع
         ↓
قرار فريق الدعم:
  • استرداد كامل للمشتري
  • استرداد جزئي
  • رفض النزاع
         ↓
إطلاق الأموال حسب القرار
```

---

## 🏗️ البنية التقنية

### Backend (Server)

**الملف الرئيسي:** `server/routers/stamp-authentication.ts`

**API Endpoints (12 إجراء):**

1. `uploadStamp` - رفع طابع للتوثيق
2. `calculateMintingCost` - حساب تكلفة السك
3. `mySubmissions` - الطوابع المرفوعة
4. `payAndMint` - الدفع وسك NFT
5. `initiatePhysicalTrade` - بدء تداول حقيقي
6. `updateShippingTracking` - تحديث الشحن
7. `confirmReceipt` - تأكيد الاستلام
8. `myTrades` - عملياتي النشطة
9. `getEscrowBalance` - الرصيد الاحتياطي
10. `searchStamps` - البحث عن طوابع
11. `getTradeDetails` - تفاصيل عملية
12. `rateUser` - تقييم المستخدم

### Frontend (Client)

**المكونات:**

1. **StampUploadForm.tsx** - نموذج رفع الطوابع
   - رفع صور متعددة
   - حساب التكلفة التلقائي
   - معاينة الصور
   - التحقق من الحقول

2. **PhysicalTrade.tsx** - واجهة التداول
   - إدارة الضمان
   - تتبع الشحن
   - تأكيد الاستلام
   - حل النزاعات

3. **MyStampsPage.tsx** - صفحة طوابعي
   - عرض جميع الطوابع
   - حالة كل طابع
   - إحصائيات
   - أزرار الإجراءات

**الصفحات:**

- `/upload` - رفع طابع جديد
- `/my-stamps` - طوابعي
- `/trade/:stampId` - تداول طابع

### قاعدة البيانات

**الجداول (7 جداول):**

#### 1. `stamp_submissions`
```sql
- id (PK)
- user_id (FK)
- title, description, country, year
- denomination, condition, rarity
- estimated_value
- images (JSON)
- auth_certificate (فريد)
- minting_cost_usd, minting_cost_stampcoins
- nft_token_id, ipfs_hash
- status
- created_at, verified_at, minted_at
```

#### 2. `user_balances`
```sql
- id (PK)
- user_id (FK, فريد)
- balance (متاح)
- escrow_locked (مقفل)
- total_earned
- total_spent
```

#### 3. `transactions`
```sql
- id (PK)
- user_id (FK)
- type (enum: minting_payment, deposit, withdrawal, nft_sale, physical_sale, escrow_deposit, escrow_release, ...)
- amount
- balance_before, balance_after
- description
- reference_id
- created_at
```

#### 4. `physical_trades`
```sql
- id (PK)
- trade_id (فريد)
- stamp_id (FK)
- seller_id, buyer_id (FK)
- agreed_price
- buyer_deposit, seller_deposit, platform_fee
- shipping_company, tracking_number, insurance_amount
- shipping_receipt, package_photos (JSON)
- buyer_address, seller_address (JSON)
- status (enum: escrow_pending, escrow_locked, shipped, in_transit, delivered, completed, disputed, cancelled)
- buyer_rating, buyer_feedback
- seller_rating, seller_feedback
- dispute_reason, dispute_resolution
- timestamps
```

#### 5. `nft_trades`
```sql
- id (PK)
- trade_id (فريد)
- nft_token_id, stamp_id
- seller_id, buyer_id
- price, platform_fee
- status
```

#### 6. `platform_revenue`
```sql
- id (PK)
- amount
- source (enum: minting_fee, escrow_trade, nft_trade, subscription)
- trade_id, submission_id
- created_at
```

#### 7. `shipping_tracking`
```sql
- id (PK)
- trade_id (FK)
- tracking_number
- shipping_company
- status, location, description
- event_time
```

---

## 🔒 الأمان والضمان

### 1. الحماية من الاحتيال

✅ **رصيد احتياطي من الطرفين**
- المشتري: يودع 110% من السعر + الشحن
- البائع: يودع 20% من قيمة الطابع

✅ **توثيق كامل**
- صور قبل الشحن (من البائع)
- صور عند الاستلام (من المشتري)
- فواتير الشحن
- رقم التتبع

✅ **التأمين على الشحن**
- إلزامي لجميع العمليات
- قيمة التأمين = قيمة الطابع (على الأقل)

### 2. شهادة التوثيق

كل طابع يحصل على شهادة فريدة:

```
STAMPCOIN-AUTH-{HASH}-{TIMESTAMP}

مثال:
STAMPCOIN-AUTH-A7F3C2E5D9B4F1A8-1704672000000
```

الشهادة تتضمن:
- معلومات الطابع كاملة
- تاريخ التوثيق
- توقيع رقمي (SHA-256)
- IPFS hash
- NFT token ID

### 3. تخزين البيانات

✅ **IPFS** - التخزين اللامركزي
- Pinata (أساسي)
- nft.storage (احتياطي)

✅ **Blockchain** - Polygon Mainnet
- عقد ذكي: `0x0E903614e8Fb61B5D36734D7B435088C5d68B963`
- معيار ERC-721

---

## 💰 الأسعار والرسوم

### رسوم السك (Minting)

| المكون | الحساب |
|--------|---------|
| التكلفة الأساسية | 1% من قيمة الطابع |
| معامل الندرة | 1.0x - 3.0x |
| أتعاب المنصة | $5 USD |
| رسوم الغاز | $0.50 USD |

### رسوم التداول

| نوع التداول | الرسوم |
|-------------|--------|
| تداول NFT | 5% من سعر البيع |
| تداول الطابع الحقيقي | 5% من سعر البيع |
| الشحن | يتحمله المشتري |
| التأمين | يتحمله البائع |

### مثال كامل (تداول طابع $1,000)

```
السعر المتفق عليه: $1,000
الشحن المقدر: $50
التأمين: $1,000

الضمان المطلوب:
├─ المشتري: $1,150 ($1,000 + $50 + $100 ضمان)
└─ البائع: $200 (20% ضمان)

عند الإتمام:
├─ البائع يستلم: $1,000
├─ المشتري يسترد: $100 (ضمان)
├─ المنصة تحصل: $50 (5%)
├─ البائع يسترد: $200 (ضمانه)
└─ تكلفة الشحن: دفعها المشتري
```

---

## 📖 دليل الاستخدام

### للبائع (صاحب الطابع)

#### 1. رفع الطابع

```bash
# الانتقال إلى صفحة الرفع
/upload

# ملء النموذج:
- عنوان: "الطابع الأسود البريطاني 1840"
- الدولة: "Great Britain"
- السنة: 1840
- الحالة: "Very Fine"
- الندرة: "Legendary"
- القيمة: $5,000
- رفع 5 صور عالية الجودة

# النظام يحسب التكلفة تلقائياً:
→ 756 StampCoins ($75.60)

# إرسال للمراجعة
```

#### 2. انتظار التوثيق

```
الحالة: pending_verification
الوقت المتوقع: 24-48 ساعة

فريق الخبراء يراجع:
- جودة الصور
- دقة المعلومات
- الحالة المذكورة
- القيمة المقدرة
```

#### 3. الدفع والسك

```
الحالة: verified ✅

# الذهاب إلى "طوابعي"
/my-stamps

# الضغط على "دفع وسك"
# تأكيد الدفع: 756 StampCoins

# النظام يسك NFT:
- رفع الميتاداتا إلى IPFS
- سك على Polygon
- إصدار شهادة توثيق

الحالة: minted ✅
```

#### 4. عرض للبيع

```
# يمكنك الآن:
1. بيع NFT (الصورة الرقمية فقط)
2. بيع الطابع الحقيقي

# لبيع الطابع الحقيقي:
- تحديد السعر
- تحديد شركة الشحن
- إدخال عنوانك
```

### للمشتري

#### 1. البحث عن طابع

```bash
# البحث في السوق
/marketplace

# تصفية حسب:
- الدولة
- الندرة
- السعر
- السنة
```

#### 2. بدء الشراء

```
# اختيار طابع
# الضغط على "شراء الطابع الحقيقي"

# إدخال:
- عنوان التسليم
- رقم الهاتف

# النظام يحسب:
- الرصيد الاحتياطي المطلوب: $1,150
- تكلفة الشحن: $50
- أتعاب المنصة: $50
```

#### 3. إيداع الضمان

```
# التأكيد على:
- السعر المتفق عليه
- عنوان التسليم
- شروط الخدمة

# إيداع الضمان من رصيدك
→ يتم قفل $1,150 في حساب الضمان
```

#### 4. تتبع الشحن

```
# البائع يشحن الطابع
# رفع:
- رقم التتبع
- فاتورة الشحن
- صور التغليف

# يمكنك تتبع الشحن مباشرة
# استلام إشعارات عند كل تحديث
```

#### 5. تأكيد الاستلام

```
# عند استلام الطابع:

# التحقق من:
- الحالة تطابق الوصف
- الطابع سليم
- التغليف سليم

# إذا كل شيء صحيح:
→ تأكيد الاستلام
→ إطلاق الأموال من الضمان
→ تقييم البائع (1-5 نجوم)

# إذا هناك مشكلة:
→ فتح نزاع
→ رفع صور للمشكلة
→ فريق الدعم يحل النزاع
```

---

## 🔌 API Documentation

### 1. uploadStamp

**رفع طابع للتوثيق**

```typescript
// Request
{
  title: string;
  description: string;
  country: string;
  year: number; // 1840-2030
  denomination: string;
  condition: 'mint' | 'very_fine' | 'fine' | 'used' | 'poor';
  rarity: 'common' | 'uncommon' | 'rare' | 'very_rare' | 'legendary';
  estimatedValue: number; // USD
  images: string[]; // Base64 or URLs
  certificateOfAuthenticity?: string;
  ownershipProof?: string;
}

// Response
{
  success: true;
  submissionId: number;
  authCertificate: string; // "STAMPCOIN-AUTH-..."
  mintingCost: {
    baseCost: number;
    rarityMultiplier: number;
    platformFee: number;
    gasFee: number;
    totalStampCoins: number;
    totalUSD: number;
  };
  message: string;
  nextStep: string;
}
```

### 2. calculateMintingCost

**حساب تكلفة السك**

```typescript
// Request
{
  stampValue: number;
  rarity: string;
}

// Response
{
  baseCost: number;
  rarityMultiplier: number;
  platformFee: number;
  gasFee: number;
  totalStampCoins: number;
  totalUSD: number;
}
```

### 3. payAndMint

**الدفع وسك NFT**

```typescript
// Request
{
  submissionId: number;
}

// Response
{
  success: true;
  message: string;
  transactionId: string;
  remainingBalance: number;
  estimatedMintingTime: string;
}
```

### 4. initiatePhysicalTrade

**بدء تداول الطابع الحقيقي**

```typescript
// Request
{
  stampId: number;
  agreedPrice: number;
  shippingCompany: 'DHL' | 'FedEx' | 'UPS' | 'USPS' | 'Aramex';
  insuranceAmount: number;
  buyerAddress: {
    fullName: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
    phone: string;
  };
  sellerAddress: { /* same structure */ };
}

// Response
{
  success: true;
  tradeId: string;
  escrowDetails: {
    buyerDeposit: number;
    sellerDeposit: number;
    platformFee: number;
    totalRequired: number;
  };
  message: string;
  nextSteps: string[];
}
```

### 5. updateShippingTracking

**تحديث معلومات الشحن**

```typescript
// Request
{
  tradeId: string;
  trackingNumber: string;
  shippingReceipt: string; // Base64 image
  packagePhotos: string[]; // Base64 images
}

// Response
{
  success: true;
  message: string;
  trackingNumber: string;
}
```

### 6. confirmReceipt

**تأكيد الاستلام**

```typescript
// Request
{
  tradeId: string;
  conditionMatch: boolean;
  receiptPhotos: string[];
  rating: number; // 1-5
  feedback?: string;
}

// Response
{
  success: true;
  message: string;
  sellerPayout?: number;
  buyerRefund?: number;
  platformFee?: number;
  disputeId?: string; // إذا !conditionMatch
}
```

---

## 🧪 الاختبار

### Setup

```bash
# تشغيل قاعدة البيانات
npm run db:migrate

# تشغيل السيرفر
npm run dev

# في نافذة أخرى: تشغيل العميل
cd client && npm run dev
```

### Test Scenarios

#### Scenario 1: رفع طابع وسكه

```bash
1. انتقل إلى /upload
2. املأ النموذج بطابع اختباري
3. ارفع صورة
4. احسب التكلفة
5. أرسل للمراجعة
6. (من الإدارة) وثق الطابع
7. ادفع وسك NFT
8. تحقق من /my-stamps
```

#### Scenario 2: تداول طابع حقيقي

```bash
1. البائع: ينشئ طابع مسكوك
2. المشتري: يبحث عن الطابع
3. المشتري: يبدأ الشراء
4. كلاهما: يودعان الضمان
5. البائع: يشحن + يرفع التتبع
6. المشتري: يستلم + يؤكد
7. إطلاق الأموال من الضمان
```

---

## 📊 الإحصائيات والمراقبة

### Metrics to Track

```sql
-- إجمالي الطوابع المرفوعة
SELECT COUNT(*) FROM stamp_submissions;

-- إجمالي الطوابع المسكوكة
SELECT COUNT(*) FROM stamp_submissions WHERE status = 'minted';

-- إجمالي قيمة الطوابع
SELECT SUM(estimated_value) FROM stamp_submissions;

-- إجمالي العمليات النشطة
SELECT COUNT(*) FROM physical_trades WHERE status IN ('escrow_locked', 'shipped', 'in_transit');

-- إيرادات المنصة
SELECT SUM(amount) FROM platform_revenue;

-- متوسط التقييم للمستخدمين
SELECT AVG(buyer_rating) FROM physical_trades WHERE buyer_rating IS NOT NULL;
```

---

## 🚀 الإطلاق

### Pre-Launch Checklist

- [ ] اختبار رفع الطوابع
- [ ] اختبار حساب التكاليف
- [ ] اختبار الدفع
- [ ] اختبار سك NFT
- [ ] اختبار نظام الضمان
- [ ] اختبار الشحن والتتبع
- [ ] اختبار تأكيد الاستلام
- [ ] اختبار حل النزاعات
- [ ] إعداد شركات الشحن API
- [ ] إعداد نظام الإشعارات
- [ ] إعداد لوحة الإدارة

### Environment Variables

```env
# Blockchain
POLYGON_RPC_URL=https://polygon-rpc.com
NFT_CONTRACT_ADDRESS=0x0E903614e8Fb61B5D36734D7B435088C5d68B963
DEPLOYER_PRIVATE_KEY=...

# IPFS
PINATA_JWT=...
NFT_STORAGE_API_KEY=...

# Database
DATABASE_URL=mysql://...

# StampCoins
STAMPCOIN_EXCHANGE_RATE=10  # 1 USD = 10 StampCoins
```

---

## 📞 الدعم

### للمستخدمين

- البريد الإلكتروني: support@stampcoin.com
- Discord: discord.gg/stampcoin
- دليل المستخدم: /docs/user-guide

### للمطورين

- GitHub: github.com/stampcoin-platform
- API Docs: /api/docs
- Postman Collection: /api/postman

---

## 📜 الترخيص

MIT License - © 2026 StampCoin Platform

---

</div>

## 🎉 خلاصة

تم إنشاء **نظام متكامل** لتوثيق وتداول الطوابع يتضمن:

✅ رفع وتوثيق الطوابع كـ NFTs  
✅ دفع بعملة المنصة (StampCoins)  
✅ تداول صور NFT  
✅ تداول الطوابع الحقيقية مع ضمان  
✅ نظام رصيد احتياطي لحماية الطرفين  
✅ تتبع الشحن والفواتير  
✅ حل النزاعات  
✅ 12 API endpoint  
✅ 7 جداول قاعدة بيانات  
✅ 3 مكونات React  
✅ توثيق شامل

**جاهز للإطلاق! 🚀**
