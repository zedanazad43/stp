# نظام النسخ الاحتياطي التلقائي | Automatic Backup System

<div dir="rtl">

## 🔄 نظام النسخ الاحتياطي الشامل

تم إعداد نظام نسخ احتياطي تلقائي كامل لحماية جميع ملفات المشروع.

---

## 📁 الهيكل

```
backups/
├── backup_YYYYMMDD_HHMMSS/          # نسخة احتياطية كاملة
│   ├── server/                      # كود الخادم
│   ├── client/                      # كود العميل
│   ├── drizzle/                     # قاعدة البيانات
│   ├── LICENSE                      # الملفات القانونية
│   ├── COPYRIGHT
│   └── ...
├── backup_YYYYMMDD_HHMMSS.tar.gz    # أرشيف مضغوط
└── legal/                           # نسخ الملفات القانونية
    └── legal_YYYYMMDD_HHMMSS.tar.gz

.backup-scripts/
├── backup.sh                        # النسخ الاحتياطي الكامل
├── watch-and-backup.sh              # المراقبة التلقائية
├── backup-legal.sh                  # نسخ الملفات القانونية
└── post-commit                      # Git hook
```

---

## 🚀 طرق الاستخدام

### 1️⃣ نسخ احتياطي يدوي فوري

```bash
# نسخة احتياطية كاملة
bash .backup-scripts/backup.sh

# نسخة احتياطية للملفات القانونية فقط
bash .backup-scripts/backup-legal.sh
```

### 2️⃣ نسخ احتياطي تلقائي مع المراقبة

```bash
# تشغيل المراقبة التلقائية (كل 5 دقائق)
bash .backup-scripts/watch-and-backup.sh &

# للإيقاف
pkill -f watch-and-backup.sh
```

### 3️⃣ نسخ احتياطي تلقائي مع Git

```bash
# تفعيل النسخ الاحتياطي بعد كل commit
bash .backup-scripts/setup-git-hooks.sh
```

---

## ⚙️ الإعدادات

### تغيير فترة المراقبة:

عدل الملف `.backup-scripts/watch-and-backup.sh`:

```bash
WATCH_INTERVAL=300  # 5 دقائق (بالثواني)
```

### تغيير عدد النسخ المحفوظة:

عدل الملف `.backup-scripts/backup.sh`:

```bash
# الاحتفاظ بآخر 10 نسخ
ls -t backup_*.tar.gz | tail -n +11 | xargs -r rm -f
```

---

## 📋 ما يتم نسخه

### ✅ تلقائياً:

1. **الملفات القانونية:**
   - LICENSE
   - COPYRIGHT
   - INTELLECTUAL_PROPERTY.md
   - TRADEMARK_NOTICE.md
   - LEGAL_PROTECTION_GUIDE.md
   - جميع ملفات IP_*

2. **ملفات المشروع:**
   - package.json
   - tsconfig.json
   - vite.config.ts
   - drizzle.config.ts
   - README.md
   - ملفات الإعداد

3. **الكود المصدري:**
   - server/ (كامل)
   - client/ (كامل)
   - drizzle/ (كامل)
   - public/ (كامل)

4. **السكريبتات:**
   - جميع ملفات .sh
   - ملفات النشر

5. **الوثائق:**
   - جميع ملفات .md
   - جميع ملفات .txt

---

## 🔍 المراقبة التلقائية

### يراقب النظام التلقائي:

- ملفات TypeScript (*.ts, *.tsx)
- ملفات JavaScript (*.js, *.jsx)
- ملفات JSON (*.json)
- ملفات Markdown (*.md)
- ملفات YAML (*.yml, *.yaml)
- الملفات القانونية

### لا يراقب:

- ❌ node_modules/
- ❌ dist/
- ❌ backups/
- ❌ .git/

---

## 🔐 الأمان

### الحماية المطبقة:

✅ النسخ الاحتياطية محلية فقط  
✅ لا يتم رفعها إلى Git  
✅ محمية في .gitignore  
✅ صلاحيات تنفيذ آمنة  

---

## 📊 إحصائيات النسخ الاحتياطي

### كل نسخة احتياطية تشمل:

```
معلومات النسخة:
├── التاريخ والوقت
├── حجم المجلد
├── حجم الأرشيف
├── المسار الكامل
└── معلومات الاستعادة
```

---

## ♻️ الاستعادة

### استعادة نسخة كاملة:

```bash
# عرض النسخ المتاحة
ls -lh backups/*.tar.gz

# استخراج نسخة
tar -xzf backups/backup_20260109_131500.tar.gz -C /desired/location/

# أو استعادة في المشروع (احذر!)
tar -xzf backups/backup_20260109_131500.tar.gz -C ./
```

### استعادة الملفات القانونية فقط:

```bash
tar -xzf backups/legal/legal_20260109_131500.tar.gz -C ./
```

---

## 🧹 التنظيف التلقائي

يقوم النظام تلقائياً بـ:

- الاحتفاظ بآخر 10 نسخ احتياطية
- حذف النسخ القديمة تلقائياً
- تنظيف المجلدات غير المضغوطة

---

## 🔧 الصيانة

### فحص حالة النظام:

```bash
# عرض النسخ الاحتياطية
ls -lh backups/

# عرض آخر نسخة
ls -t backups/*.tar.gz | head -1

# حساب الحجم الإجمالي
du -sh backups/
```

### تنظيف يدوي:

```bash
# حذف جميع النسخ القديمة
rm -rf backups/backup_*

# الاحتفاظ بالنسخ الأخيرة فقط
cd backups && ls -t backup_*.tar.gz | tail -n +6 | xargs rm -f
```

---

## ⚡ الأوامر السريعة

```bash
# نسخ احتياطي فوري
bash .backup-scripts/backup.sh

# نسخ قانوني فقط
bash .backup-scripts/backup-legal.sh

# بدء المراقبة
bash .backup-scripts/watch-and-backup.sh &

# إيقاف المراقبة
pkill -f watch-and-backup

# عرض آخر نسخة
ls -lht backups/*.tar.gz | head -1

# استعادة نسخة
tar -xzf backups/backup_TIMESTAMP.tar.gz -C ./
```

---

## 📞 المساعدة

عند مواجهة مشاكل:

1. تحقق من الصلاحيات:
   ```bash
   chmod +x .backup-scripts/*.sh
   ```

2. تحقق من المساحة:
   ```bash
   df -h
   ```

3. راجع السجلات:
   ```bash
   cat backups/backup_*/BACKUP_INFO.txt
   ```

---

## 🎯 أفضل الممارسات

1. ✅ شغل المراقبة التلقائية دائماً
2. ✅ قم بنسخ يدوي قبل التغييرات الكبيرة
3. ✅ انسخ backups/ إلى مكان خارجي بشكل دوري
4. ✅ تحقق من النسخ بشكل منتظم
5. ✅ اختبر الاستعادة بشكل دوري

---

</div>

---

## AUTOMATIC BACKUP SYSTEM (English)

### Quick Commands:

```bash
# Full backup
bash .backup-scripts/backup.sh

# Legal files backup
bash .backup-scripts/backup-legal.sh

# Start automatic monitoring
bash .backup-scripts/watch-and-backup.sh &

# Restore backup
tar -xzf backups/backup_TIMESTAMP.tar.gz -C ./
```

### Features:

✅ Automatic file monitoring  
✅ Git commit integration  
✅ Compressed archives  
✅ Auto cleanup (keeps last 10)  
✅ Legal files protection  
✅ Complete project backup  

---

**© 2024-2026 Stampcoin Platform. All Rights Reserved.**

**Last Updated:** January 9, 2026  
**Version:** 1.0.0
