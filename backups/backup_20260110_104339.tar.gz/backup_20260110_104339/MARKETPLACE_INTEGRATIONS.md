# 🖼️ Marketplace Integrations: KnownOrigin & SuperRare

هذا الدليل يشرح كيفية الحصول على حضور رسمي للنطاق/العلامة التجارية على منصتي KnownOrigin و SuperRare، وربط نطاقك بالمظهر العام.

---

## ✅ الأهداف
- إنشاء ملفات رسمية للعلامة التجارية على KnownOrigin و SuperRare
- ربط النطاقات بـ صفحات المنصات عبر إعادة توجيه سريعة
- تجهيز المتطلبات لقبول الطلبات (مراجعة مُختارة/منسّقة)

---

## 🔗 روابط سريعة
- KnownOrigin: https://knownorigin.io
- SuperRare: https://superrare.com

بعد الموافقة، عيّن:
- `KO_PROFILE_URL` → رابط صفحة الفنان/المجموعة على KnownOrigin
- `SR_PROFILE_URL` → رابط صفحة الفنان/المجموعة على SuperRare

وسيمكن الوصول عبر:
- `https://yourdomain.com/knownorigin`
- `https://yourdomain.com/superrare`

---

## 📋 المتطلبات الأساسية
- محفظة Web3 (MetaMask) مخصصة للعلامة التجارية
- نماذج NFT أصلية (صور عالية الدقة + وصف + بيانات)
- موقع رسمي (هذا النطاق)
- حسابات اجتماعية موثّقة (Twitter/X, Instagram, Discord)
- ملف تعريفي للشركة/الفنان + سيرة قصيرة
- إثباتات ملكية العمل (إن أمكن)

---

## 🧾 KnownOrigin: خطوات القبول
1. اطلع على سياسة القبول: https://knownorigin.io/policy
2. جهّز ملف الطلب:
   - سيرة مختصرة للفنان/العلامة
   - روابط الأعمال السابقة + موقع رسمي
   - محفظة الإيثيريوم الخاصة بالمنصة
3. قدّم طلب الانضمام (Curated onboarding)
4. بعد القبول، حدّد مسار الصفحة (slug) مثل: `artist/stampcoin`
5. أضف الرابط إلى `KO_PROFILE_URL` في بيئة الإنتاج

نصيحة: اعرض مشروع الأرشفة التاريخية للطوابع + الندرة + التوثيق عبر خبراء لزيادة فرص القبول.

---

## 🧾 SuperRare: خطوات القبول
1. اقرأ شروط القبول: https://superrare.com/apply
2. جهّز:
   - سيرة فنية + رؤية المشروع
   - نماذج أعمال عالية الجودة
   - إثبات أصالة + سياق فني واضح
3. قدّم طلب الانضمام (Invite-only/curated)
4. بعد القبول، احصل على صفحة مخصصة مثل: `superrare.com/stampcoin`
5. أضف الرابط إلى `SR_PROFILE_URL` في بيئة الإنتاج

نصيحة: أبرز نظام التوثيق، الندرة، والتكامل مع الخبراء والأرشيف.

---

## 🌐 ربط النطاق بالمنصات
### عبر الخادم (تم تنفيذه)
أضفنا مسارات إعادة توجيه:
- `/knownorigin` → `KO_PROFILE_URL`
- `/superrare` → `SR_PROFILE_URL`
- أيضًا عبر `/market/knownorigin` و `/market/superrare`

### تحديث البيئة (Production)
ضع القيم في `.env.production`:
```
KO_PROFILE_URL=https://knownorigin.io/artist/stampcoin
SR_PROFILE_URL=https://superrare.com/stampcoin
```

أعد النشر:
```
pnpm build && flyctl deploy
```

---

## 🧪 التحقق بعد الإعداد
```
# صحة الروابط
curl -I https://yourdomain.com/knownorigin
curl -I https://yourdomain.com/superrare

# يستجيب بتحويل 302 إلى المنصة
```

---

## 📎 مواد داعمة للطلب
- عرض بصري للأرشيف: صفحات `StampArchive` + أمثلة
- توثيق النظام: ملفات `NFT_SYSTEM_ARCHITECTURE.md`, `STAMP_AUTHENTICATION_SYSTEM.md`
- أمثلة سكّ + بيانات IPFS
- شراكات/خبراء: `EXPERT_NETWORK_DOCUMENTATION.md`

---

## 🛡️ التحقق من الملكية
منصات منسّقة قد تطلب:
- إضافة TXT record في DNS للتأكد من ملكية النطاق
- نشر منشور رسمي من حسابات التواصل
- توقيع الرسائل بالمحفظة

### مثال TXT Record (افتراضي)
```
Type: TXT
Host: _ko-verify
Value: knownorigin-verification=STAMP-<unique-token>
TTL: Auto
```

ضع التعليمات حسب ما تزودك به المنصة بعد طلب القبول.

---

## 🧭 خارطة الطريق
- الأسبوع 1: تجهيز ملف الطلب + مواد بصرية
- الأسبوع 2: التقديم إلى KnownOrigin
- الأسبوع 3: التقديم إلى SuperRare
- الأسبوع 4+: متابعة الطلبات + إعداد الروابط + حملات PR

---

## 🆘 دعم
- KnownOrigin: https://help.knownorigin.io
- SuperRare: https://help.superrare.com

---

تم إعداد هذا التكامل لدعم حضور StampCoin في أسواق NFT المنسّقة وربط النطاقات مباشرة بصفحات العرض بمجرد الموافقة.
